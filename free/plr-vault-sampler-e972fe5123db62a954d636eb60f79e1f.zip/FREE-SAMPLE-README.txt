PLR VAULT — FREE SAMPLER
=======================
This is a free sample of the PLR Vault ($9.95 one-time).

INSIDE THIS SAMPLE:
- free-5-email-swipes.md ......... 5 of the 50 email swipes
- free-3-day-calendar-sample.md ... 3 of the 30-day content calendar
- free-mini-course-outline.md ..... 1 of the 8 mini-course blueprints
- free-january-2026-planner.svg ... 1 of 12 monthly planner SVGs (editable in Canva)

THE FULL VAULT ADDS: all 12 monthly planners + weekly/daily/goals/review/habit
pages, the complete 30-day calendar, all 50 swipes, all 8 course blueprints,
and the plain-English PLR license (rebrand it, resell it, keep 100%).

Get it: https://plrvault.mehyar.us

Sample terms: use these files personally all you want. Resell rights apply
only to the paid vault, not to this free sample.
