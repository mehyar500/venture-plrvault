# FREE SAMPLE — 5 Email Swipes (from PLR Vault)
The full vault has 50. https://plrvault.mehyar.us

---

## WELCOME SEQUENCE

### W-1 — The delivery
**Purpose:** Deliver the lead magnet, set the tone.
**Subjects:** "Here's your [LEAD MAGNET] (takes 4 minutes)" / "You asked, I delivered" / "Start here, [FIRST NAME]"
**Body:**
Hey [FIRST NAME],

Your [LEAD MAGNET NAME] is attached — or grab it here: [LINK]

Quick start: skip to page [X]. Do that one thing today and you'll already be ahead of 90% of people who download freebies and never open them.

I'm [YOUR NAME]. I help [AUDIENCE] get [OUTCOME] without [COMMON PAIN]. You'll hear from me a few times a week — always something useful, never fluff. If that's not your thing, unsubscribe below, no hard feelings.

Talk soon,
[YOUR NAME]

### W-2 — The story
**Purpose:** Build connection, earn the open habit.
**Subjects:** "Why I do this (the short version)" / "Nobody asked, but here's my story" / "The part I usually skip"
**Body:**
[FIRST NAME], quick story.

[1-2 sentences: where you were — the frustration, the stuck feeling.]

[1-2 sentences: the shift — what you tried, what finally clicked.]

[1-2 sentences: where you are now and why you teach this.]

I tell you this because if you're where I was, I want you to know the gap is smaller than it looks. Tomorrow I'll share the [FRAMEWORK/CHECKLIST] that changed everything for me.

[YOUR NAME]

P.S. Hit reply and tell me where you're stuck — I read everything.

### W-3 — The quick win
**Purpose:** Deliver value fast, build authority.
**Subjects:** "Do this today, thank me Friday" / "The 10-minute win" / "Steal my [TACTIC]"
**Body:**
Here's something you can use in the next 10 minutes:

[TACTIC NAME]: [2-3 sentence explanation of the tactic.]

Why it works: [one sentence on the mechanism.]

Try it today and reply with your result — I collect these and share the best ones (with your permission).

This is the kind of thing I send every week. Small, usable, no theory.

[YOUR NAME]

### W-4 — The belief shift
**Purpose:** Break the objection stopping them.
**Subjects:** "You're not behind. You're just early." / "The lie keeping you stuck" / "Read this before you quit"
**Body:**
[FIRST NAME], the story you're telling yourself is wrong.

You think: "[COMMON LIMITING BELIEF — e.g. I need a bigger audience first.]"

Reality: [2-3 sentences dismantling it with logic or a mini case study.]

The people getting results aren't smarter or luckier. They just stopped waiting for permission. You already have permission — you had it the whole time.

Tomorrow: the [RESOURCE] I wish someone handed me at the start.

[YOUR NAME]

### W-5 — The soft offer
**Purpose:** First pitch, low pressure.
**Subjects:** "If you want the shortcut..." / "I made this for you" / "The next step (only if you want it)"
**Body:**
Hey [FIRST NAME],

Over the last few days I've shared [RECAP: the story, the tactic, the mindset shift]. If you want to go deeper, I built [PRODUCT NAME] for exactly that.

It's [ONE-LINE DESCRIPTION]. It helps you [OUTCOME] without [PAIN].

Here's the link: [LINK]

No pressure — the free stuff keeps coming either way. But if you're ready to move faster, this is the shortcut.

[YOUR NAME]

